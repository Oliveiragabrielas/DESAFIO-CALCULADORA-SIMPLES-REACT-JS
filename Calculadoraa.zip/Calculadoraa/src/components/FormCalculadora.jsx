import { useState } from 'react'
import './FormCalculadora.jsx'

function FormCalculadora() {
  const [num1, setNum1] = useState('')
  const [num2, setNum2] = useState('')
  const [operador, setOperador] = useState('+')
  const [resultado, setResultado] = useState('')

  function calcular() {
    const n1 = parseFloat(num1)
    const n2 = parseFloat(num2)

    if (isNaN(n1) || isNaN(n2)) {
      setResultado('Digite os dois números')
      return
    }

    if (operador === '+') {
      setResultado(n1 + n2)
    } else if (operador === '-') {
      setResultado(n1 - n2)
    } else if (operador === '*') {
      setResultado(n1 * n2)
    } else if (operador === '/') {
      if (n2 === 0) {
        setResultado('Não é possível dividir por zero')
      } else {
        setResultado(n1 / n2)
      }
    }
  }

  function limpar() {
    setNum1('')
    setNum2('')
    setOperador('+')
    setResultado('')
  }

  return (
    <div className="calculadora">
      <h1>Calculadora Simples</h1>

      <input
        type="number"
        placeholder="Primeiro número"
        value={num1}
        onChange={(e) => setNum1(e.target.value)}
      />

      <select value={operador} onChange={(e) => setOperador(e.target.value)}>
        <option value="+">+</option>
        <option value="-">-</option>
        <option value="*">*</option>
        <option value="/">/</option>
      </select>

      <input
        type="number"
        placeholder="Segundo número"
        value={num2}
        onChange={(e) => setNum2(e.target.value)}
      />

      <div className="botoes">
        <button onClick={calcular}>Calcular</button>
        <button onClick={limpar}>Limpar</button>
      </div>

      <h2>Resultado: {resultado}</h2>
    </div>
  )
}

export default FormCalculadora