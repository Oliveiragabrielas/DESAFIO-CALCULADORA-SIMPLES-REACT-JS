
import FormCalculadora from './components/FormCalculadora.jsx'

function App() {
  return (
    <div>
      <FormCalculadora />
    </div>
  )
}

export default App